export const increment = (state) => {
      // 变更状态
      state.text = 'DSB'
}

export const qwe = (state) => {
	state.text = 'qwe'
}