const state = {
  text: 'XSB',
}
export default state;